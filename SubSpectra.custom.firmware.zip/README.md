# SubSpectra - Flipper Zero Custom Firmware

SubSpectra is a custom firmware for Flipper Zero focused on fun, customization, and expanded capabilities:

- Funny animations and themes
- More customization options
- Infrared, Sub-GHz, NFC, RF tools
- Games and entertainment
- GPIO, Bluetooth, and USB tools
- Download files directly from your Flipper Zero

## Building

1. Clone this repo:  
   `git clone https://github.com/SYOP200/-.git`
2. Follow Flipper Zero firmware build instructions [here](https://github.com/flipperdevices/flipperzero-firmware#building)
3. Copy or link your custom apps and assets into `/apps/` and `/assets/`
4. Run `./fbt` to build!

## Adding Features

- Place new apps in `/apps/`
- Add assets (images, sounds) in `/assets/`
- Document your tools in `/docs/`

## License

MIT
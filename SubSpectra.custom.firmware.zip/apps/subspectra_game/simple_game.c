#include <furi.h>
#include <gui/gui.h>

int32_t simple_game_app(void* p) {
    // Simple button-mash counter
    uint32_t score = 0;
    // Game loop omitted
    return 0;
}